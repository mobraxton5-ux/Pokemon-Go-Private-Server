#~/bin/bash
./compile.py 